<?php 
include('header.php'); 
?>
			<div>
				<ul class="breadcrumb">
					<li>
						<a href="index.php">Home</a> <span class="divider">/</span>
					</li>
					<li>
						<a href="#"></a>
					</li>
				</ul>
			</div>
			
			<div class="row-fluid">
				<div class="box span12">
					<div class="box-header well">
						<h2><i class="icon-info-sign"></i>Tentang Mas-Maal</h2>
					</div>
					<div class="box-content">
					<div class="page-header">
					<h1>MAS-MAAL <small>Pengelolaan Keuangan Masjid</small></h1>
					</div>
						<p>Aplikasi keuangan yang dibuat dan didesain dalam memberikan laporan keuangan khususnya Masjid. 
						Aplikasi ini mampu menampilkan laporan secara detail dan juga grafik.Sehingga masjid dapat melihat, membandingkan serta 
						mempertimbangkan keadaan dan rencana keuangan selanjutnya.</p>
						<p><blockquote><b>When Operating, Editing, and Publishing Become Easy</b></blockquote></p>
						<div class="clearfix"></div>
					</div>
				</div>
			</div>
<?php include('footer.php'); ?>
